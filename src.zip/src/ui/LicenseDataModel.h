#ifndef LICENSEDATAMODEL_H
#define LICENSEDATAMODEL_H

#include <QString>
#include <QDateTime>
#include <QColor>

// License status enum
enum class LicenseStatus {
    Legitimate,
    Cracked,
    NotLicensed,
    UnableToDetermine
};

// KMS status enum
enum class KMSStatus {
    NotKMS,
    KMSDetected,
    KMSNotFound,
    Error
};

// Represents Windows or Office license data
struct LicenseInfo {
    QString edition;              // Windows 10 Pro, Office 365 ProPlus
    LicenseStatus licenseStatus;  // Legitimate/Cracked/NotLicensed/Unknown
    KMSStatus kmsStatus;          // NotKMS/KMSDetected/KMSNotFound/Error
    QString kmsServer;            // kms.corp.local
    QString gracePeriod;          // "Not In Grace Period" or "30 days remaining"
    QDateTime lastDetected;       // When was this last checked?
    bool isError;
    QString errorMessage;

    LicenseInfo()
        : licenseStatus(LicenseStatus::UnableToDetermine),
          kmsStatus(KMSStatus::Error),
          isError(false) {}
};

// Represents system info
struct SystemInfo {
    QString machineGuid;
    QString hostname;
    QString department;
    bool serviceRunning;
    QDateTime lastReportTime;

    SystemInfo() : serviceRunning(false) {}
};

// Main data model
class LicenseDataModel {
public:
    LicenseDataModel();

    // Windows license data
    LicenseInfo& windowsLicense() { return m_windowsLicense; }
    const LicenseInfo& windowsLicense() const { return m_windowsLicense; }

    // Office license data
    LicenseInfo& officeLicense() { return m_officeLicense; }
    const LicenseInfo& officeLicense() const { return m_officeLicense; }

    // System info
    SystemInfo& systemInfo() { return m_systemInfo; }
    const SystemInfo& systemInfo() const { return m_systemInfo; }

    // Load data from service (registry/JSON file)
    bool loadFromRegistry();
    bool loadFromJsonFile(const QString& filePath);

    // Helper functions
    QString getLicenseStatusString(LicenseStatus status) const;
    QString getKMSStatusString(KMSStatus status) const;
    QColor getLicenseStatusColor(LicenseStatus status) const;

    // Update timestamp when data is refreshed
    void updateRefreshTime();
    QDateTime lastRefreshTime() const { return m_lastRefreshTime; }

private:
    LicenseInfo m_windowsLicense;
    LicenseInfo m_officeLicense;
    SystemInfo m_systemInfo;
    QDateTime m_lastRefreshTime;
};

#endif // LICENSEDATAMODEL_H
