#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSystemTrayIcon>
#include <QTimer>
#include <memory>
#include "LicenseDataModel.h"

class NamedPipeClient;

class QTabWidget;
class QLabel;
class QPushButton;
class QGroupBox;
class SystemTrayIcon;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void changeEvent(QEvent *event) override;
    void closeEvent(QCloseEvent *event) override;

private slots:
    void onRefreshLicenseData();
    void onForceCheckNow();
    void onCheckInCompleted();
    void onSystemTrayActivated(QSystemTrayIcon::ActivationReason reason);

private:
    void createUI();
    void createWindowsLicenseTab();
    void createOfficeLicenseTab();
    void createSettingsTab();
    void createStatusBar();
    void createSystemTray();

    void updateLicenseDisplay();
    void updateWindowsLicenseTab();
    void updateOfficeLicenseTab();
    void displayLicenseInfo(const LicenseInfo& license, QGroupBox* group);

    QString formatDateTime(const QDateTime& dt) const;
    QString getStatusBadgeHtml(const LicenseInfo& license) const;

    // UI Components
    QTabWidget *m_tabWidget;
    QLabel *m_systemInfoLabel;
    QLabel *m_windowsStatusLabel;
    QLabel *m_windowsEditionLabel;
    QLabel *m_windowsKmsLabel;
    QLabel *m_windowsGracePeriodLabel;
    QLabel *m_windowsLastDetectedLabel;

    QLabel *m_officeStatusLabel;
    QLabel *m_officeEditionLabel;
    QLabel *m_officeKmsLabel;
    QLabel *m_officeGracePeriodLabel;
    QLabel *m_officeLastDetectedLabel;

    QLabel *m_hostnameLabel;
    QLabel *m_machineGuidLabel;
    QLabel *m_departmentLabel;
    QLabel *m_serviceStatusLabel;
    QLabel *m_lastReportLabel;

    QPushButton *m_forceCheckButton;
    QLabel *m_refreshStatusLabel;

    // System tray
    SystemTrayIcon *m_trayIcon;

    // Data model
    LicenseDataModel m_dataModel;

    // Named pipe client for service communication
    std::unique_ptr<NamedPipeClient> m_pipeClient;

    // Auto-refresh timer
    QTimer *m_refreshTimer;
    int m_refreshIntervalSeconds;
};

#endif // MAINWINDOW_H
