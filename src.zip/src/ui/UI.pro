TEMPLATE = app
CONFIG += c++17

TARGET = LicenseCheckerUI

QT += core gui widgets network

SOURCES += \
    main.cpp \
    MainWindow.cpp \
    SystemTrayIcon.cpp \
    LicenseDataModel.cpp

HEADERS += \
    MainWindow.h \
    SystemTrayIcon.h \
    LicenseDataModel.h

win32 {
    LIBS += -ladvapi32 -lkernel32 -lws2_32
}

# Link to our libraries
win32-g++ {
    LIBS += \
        -L$$OUT_PWD/../license-detection -llicense_detection \
        -L$$OUT_PWD/../common -lcommon
}

INCLUDEPATH += $$PWD \
               $$PWD/../license-detection \
               $$PWD/../common

DEPENDPATH += $$PWD/../license-detection \
              $$PWD/../common

# Application icon (optional)
# RC_ICONS = app.ico
