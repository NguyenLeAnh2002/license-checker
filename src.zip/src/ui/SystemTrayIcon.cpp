#include "SystemTrayIcon.h"
#include <QApplication>
#include <QAction>
#include <QMenu>
#include <QDateTime>

SystemTrayIcon::SystemTrayIcon(QObject *parent)
    : QSystemTrayIcon(parent),
      m_contextMenu(nullptr),
      m_showAction(nullptr),
      m_checkNowAction(nullptr),
      m_quitAction(nullptr),
      m_currentStatus("Unknown"),
      m_lastCheckTime("Never")
{
    createContextMenu();

    connect(this, QOverload<QSystemTrayIcon::ActivationReason>::of(&QSystemTrayIcon::activated),
            this, &SystemTrayIcon::onActivated);
}

SystemTrayIcon::~SystemTrayIcon()
{
    if (m_contextMenu) {
        delete m_contextMenu;
    }
}

void SystemTrayIcon::createContextMenu()
{
    m_contextMenu = new QMenu();

    m_showAction = m_contextMenu->addAction("Show");
    connect(m_showAction, &QAction::triggered, this, &SystemTrayIcon::onShowAction);

    m_contextMenu->addSeparator();

    m_checkNowAction = m_contextMenu->addAction("Check Now");
    connect(m_checkNowAction, &QAction::triggered, this, &SystemTrayIcon::onCheckNowAction);

    m_contextMenu->addSeparator();

    m_quitAction = m_contextMenu->addAction("Quit");
    connect(m_quitAction, &QAction::triggered, this, &SystemTrayIcon::onQuitAction);

    setContextMenu(m_contextMenu);
}

void SystemTrayIcon::onActivated(QSystemTrayIcon::ActivationReason reason)
{
    if (reason == QSystemTrayIcon::DoubleClick) {
        emit doubleActivated();
    } else if (reason == QSystemTrayIcon::Trigger) {
        // Single click on some platforms
        showStatusPopup();
    }
}

void SystemTrayIcon::onShowAction()
{
    emit doubleActivated();
}

void SystemTrayIcon::onCheckNowAction()
{
    // Signal to main window to check now
    showMessage("License Checker", "Checking licenses...", QSystemTrayIcon::Information, 3000);
}

void SystemTrayIcon::onQuitAction()
{
    qApp->quit();
}

void SystemTrayIcon::showStatusPopup()
{
    // Show a notification with current status
    QString title = "License Checker Status";
    QString message = QString("Windows: %1\nOffice: %2\nLast Check: %3")
        .arg(m_currentStatus, m_currentStatus, m_lastCheckTime);

    showMessage(title, message, QSystemTrayIcon::Information, 5000);
}
