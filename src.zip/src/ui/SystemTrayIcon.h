#ifndef SYSTEMTRAYICON_H
#define SYSTEMTRAYICON_H

#include <QSystemTrayIcon>
#include <QMenu>

class SystemTrayIcon : public QSystemTrayIcon {
    Q_OBJECT

public:
    explicit SystemTrayIcon(QObject *parent = nullptr);
    ~SystemTrayIcon();

signals:
    void doubleActivated();

private slots:
    void onActivated(QSystemTrayIcon::ActivationReason reason);
    void onShowAction();
    void onCheckNowAction();
    void onQuitAction();

private:
    void createContextMenu();
    void showStatusPopup();

    QMenu *m_contextMenu;
    QAction *m_showAction;
    QAction *m_checkNowAction;
    QAction *m_quitAction;

    QString m_currentStatus;
    QString m_lastCheckTime;
};

#endif // SYSTEMTRAYICON_H
