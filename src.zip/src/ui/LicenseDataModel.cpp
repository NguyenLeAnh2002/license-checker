#include "LicenseDataModel.h"
#include <QSettings>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QColor>

LicenseDataModel::LicenseDataModel()
{
    m_lastRefreshTime = QDateTime::currentDateTime();
}

bool LicenseDataModel::loadFromRegistry()
{
    // Read from Windows Registry
    // HKEY_LOCAL_MACHINE\SOFTWARE\LicenseCheckerAgent
    // This data is written by the background service

    QSettings settings(
        "HKEY_LOCAL_MACHINE\\SOFTWARE\\LicenseCheckerAgent",
        QSettings::NativeFormat
    );

    // Load system info
    m_systemInfo.machineGuid = settings.value("MachineGuid", "Unknown").toString();
    m_systemInfo.hostname = settings.value("Hostname", "Unknown").toString();
    m_systemInfo.department = settings.value("Department", "Unknown").toString();

    // Try to load license data
    // Note: Service writes license data as JSON in registry value or separate file

    QString windowsJson = settings.value("WindowsLicense", "").toString();
    QString officeJson = settings.value("OfficeLicense", "").toString();

    if (!windowsJson.isEmpty()) {
        QJsonDocument doc = QJsonDocument::fromJson(windowsJson.toUtf8());
        if (!doc.isNull()) {
            QJsonObject obj = doc.object();
            m_windowsLicense.edition = obj["edition"].toString();
            m_windowsLicense.licenseStatus =
                static_cast<LicenseStatus>(obj["licenseStatus"].toInt());
            m_windowsLicense.kmsStatus =
                static_cast<KMSStatus>(obj["kmsStatus"].toInt());
            m_windowsLicense.kmsServer = obj["kmsServer"].toString();
            m_windowsLicense.gracePeriod = obj["gracePeriod"].toString();
            m_windowsLicense.lastDetected =
                QDateTime::fromString(obj["lastDetected"].toString(), Qt::ISODate);
        }
    }

    if (!officeJson.isEmpty()) {
        QJsonDocument doc = QJsonDocument::fromJson(officeJson.toUtf8());
        if (!doc.isNull()) {
            QJsonObject obj = doc.object();
            m_officeLicense.edition = obj["edition"].toString();
            m_officeLicense.licenseStatus =
                static_cast<LicenseStatus>(obj["licenseStatus"].toInt());
            m_officeLicense.kmsStatus =
                static_cast<KMSStatus>(obj["kmsStatus"].toInt());
            m_officeLicense.kmsServer = obj["kmsServer"].toString();
            m_officeLicense.gracePeriod = obj["gracePeriod"].toString();
            m_officeLicense.lastDetected =
                QDateTime::fromString(obj["lastDetected"].toString(), Qt::ISODate);
        }
    }

    updateRefreshTime();
    return true;
}

bool LicenseDataModel::loadFromJsonFile(const QString& filePath)
{
    // Alternative: Load from JSON file written by service
    // Path: C:\ProgramData\LicenseCheckerAgent\license_data.json

    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }

    QByteArray data = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isNull() && doc.isObject()) {
        QJsonObject root = doc.object();

        // Load system info
        QJsonObject sysObj = root["system"].toObject();
        m_systemInfo.machineGuid = sysObj["machineGuid"].toString();
        m_systemInfo.hostname = sysObj["hostname"].toString();
        m_systemInfo.department = sysObj["department"].toString();
        m_systemInfo.lastReportTime =
            QDateTime::fromString(sysObj["lastReportTime"].toString(), Qt::ISODate);

        // Load Windows license
        QJsonObject winObj = root["windows"].toObject();
        m_windowsLicense.edition = winObj["edition"].toString();
        m_windowsLicense.licenseStatus =
            static_cast<LicenseStatus>(winObj["licenseStatus"].toInt());
        m_windowsLicense.kmsStatus =
            static_cast<KMSStatus>(winObj["kmsStatus"].toInt());
        m_windowsLicense.kmsServer = winObj["kmsServer"].toString();
        m_windowsLicense.gracePeriod = winObj["gracePeriod"].toString();
        m_windowsLicense.lastDetected =
            QDateTime::fromString(winObj["lastDetected"].toString(), Qt::ISODate);

        // Load Office license
        QJsonObject offObj = root["office"].toObject();
        m_officeLicense.edition = offObj["edition"].toString();
        m_officeLicense.licenseStatus =
            static_cast<LicenseStatus>(offObj["licenseStatus"].toInt());
        m_officeLicense.kmsStatus =
            static_cast<KMSStatus>(offObj["kmsStatus"].toInt());
        m_officeLicense.kmsServer = offObj["kmsServer"].toString();
        m_officeLicense.gracePeriod = offObj["gracePeriod"].toString();
        m_officeLicense.lastDetected =
            QDateTime::fromString(offObj["lastDetected"].toString(), Qt::ISODate);

        updateRefreshTime();
        return true;
    }

    return false;
}

QString LicenseDataModel::getLicenseStatusString(LicenseStatus status) const
{
    switch (status) {
        case LicenseStatus::Legitimate:
            return "Legitimate";
        case LicenseStatus::Cracked:
            return "Cracked";
        case LicenseStatus::NotLicensed:
            return "Not Licensed";
        case LicenseStatus::UnableToDetermine:
        default:
            return "Unable to Determine";
    }
}

QString LicenseDataModel::getKMSStatusString(KMSStatus status) const
{
    switch (status) {
        case KMSStatus::KMSDetected:
            return "KMS Detected";
        case KMSStatus::NotKMS:
            return "Not KMS";
        case KMSStatus::KMSNotFound:
            return "KMS Not Found";
        case KMSStatus::Error:
        default:
            return "Error";
    }
}

QColor LicenseDataModel::getLicenseStatusColor(LicenseStatus status) const
{
    switch (status) {
        case LicenseStatus::Legitimate:
            return QColor(40, 167, 69);      // Green
        case LicenseStatus::Cracked:
            return QColor(220, 53, 69);      // Red
        case LicenseStatus::NotLicensed:
            return QColor(255, 193, 7);      // Yellow/Orange
        case LicenseStatus::UnableToDetermine:
        default:
            return QColor(108, 117, 125);    // Gray
    }
}

void LicenseDataModel::updateRefreshTime()
{
    m_lastRefreshTime = QDateTime::currentDateTime();
}
