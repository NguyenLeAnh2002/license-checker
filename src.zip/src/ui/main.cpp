#include <QApplication>
#include <QSplashScreen>
#include <QPixmap>
#include <QDateTime>
#include "MainWindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // Set application metadata
    app.setApplicationName("License Checker");
    app.setApplicationVersion("1.0.0");
    app.setApplicationDisplayName("License Checker");

    // Create and show main window
    MainWindow window;
    window.show();

    return app.exec();
}
