#include "MainWindow.h"
#include "SystemTrayIcon.h"
#include "../common/NamedPipeClient.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QTabWidget>
#include <QLabel>
#include <QPushButton>
#include <QGroupBox>
#include <QSystemTrayIcon>
#include <QApplication>
#include <QTimer>
#include <QStatusBar>
#include <QDateTime>
#include <QEvent>
#include <QCloseEvent>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QIcon>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      m_tabWidget(nullptr),
      m_trayIcon(nullptr),
      m_pipeClient(std::make_unique<NamedPipeClient>("LicenseChecker")),
      m_refreshTimer(nullptr),
      m_refreshIntervalSeconds(300) // 5 minutes
{
    setWindowTitle("License Checker");
    setWindowIcon(QIcon(":/resources/icon.png")); // Placeholder
    setMinimumSize(600, 500);

    createUI();
    createSystemTray();
    createStatusBar();

    // Try to connect to service
    if (!m_pipeClient->Connect()) {
        statusBar()->showMessage("Warning: Service not running");
    }

    // Setup auto-refresh timer (every 5 minutes)
    m_refreshTimer = new QTimer(this);
    connect(m_refreshTimer, &QTimer::timeout, this, &MainWindow::onRefreshLicenseData);
    m_refreshTimer->start(m_refreshIntervalSeconds * 1000);

    // Initial load
    onRefreshLicenseData();
}

MainWindow::~MainWindow()
{
    if (m_refreshTimer) {
        m_refreshTimer->stop();
    }
}

void MainWindow::createUI()
{
    // Central widget
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

    // Tab widget
    m_tabWidget = new QTabWidget(this);

    createWindowsLicenseTab();
    createOfficeLicenseTab();
    createSettingsTab();

    mainLayout->addWidget(m_tabWidget);

    // Bottom button bar
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    m_forceCheckButton = new QPushButton("Check Now", this);
    m_refreshStatusLabel = new QLabel("Ready", this);

    connect(m_forceCheckButton, &QPushButton::clicked, this, &MainWindow::onForceCheckNow);

    buttonLayout->addStretch();
    buttonLayout->addWidget(m_refreshStatusLabel);
    buttonLayout->addWidget(m_forceCheckButton);
    buttonLayout->addSpacing(10);

    mainLayout->addLayout(buttonLayout);
    mainLayout->setContentsMargins(10, 10, 10, 10);

    setCentralWidget(centralWidget);
}

void MainWindow::createWindowsLicenseTab()
{
    QWidget *tabWidget = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(tabWidget);

    // Status card
    QGroupBox *statusGroup = new QGroupBox("License Status", tabWidget);
    QVBoxLayout *statusLayout = new QVBoxLayout(statusGroup);

    m_windowsStatusLabel = new QLabel("Status: <font color='red'><b>Unable to Determine</b></font>", statusGroup);
    m_windowsStatusLabel->setStyleSheet("padding: 5px; border-radius: 3px; background-color: #f8f9fa;");

    statusLayout->addWidget(m_windowsStatusLabel);
    layout->addWidget(statusGroup);

    // Details card
    QGroupBox *detailsGroup = new QGroupBox("Details", tabWidget);
    QGridLayout *detailsLayout = new QGridLayout(detailsGroup);

    m_windowsEditionLabel = new QLabel("Edition: <b>Unknown</b>", detailsGroup);
    m_windowsKmsLabel = new QLabel("KMS Server: Not Detected", detailsGroup);
    m_windowsGracePeriodLabel = new QLabel("Grace Period: N/A", detailsGroup);
    m_windowsLastDetectedLabel = new QLabel("Last Detected: Never", detailsGroup);

    detailsLayout->addWidget(m_windowsEditionLabel, 0, 0);
    detailsLayout->addWidget(m_windowsKmsLabel, 1, 0);
    detailsLayout->addWidget(m_windowsGracePeriodLabel, 2, 0);
    detailsLayout->addWidget(m_windowsLastDetectedLabel, 3, 0);

    layout->addWidget(detailsGroup);
    layout->addStretch();

    m_tabWidget->addTab(tabWidget, "Windows License");
}

void MainWindow::createOfficeLicenseTab()
{
    QWidget *tabWidget = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(tabWidget);

    // Status card
    QGroupBox *statusGroup = new QGroupBox("License Status", tabWidget);
    QVBoxLayout *statusLayout = new QVBoxLayout(statusGroup);

    m_officeStatusLabel = new QLabel("Status: <font color='red'><b>Unable to Determine</b></font>", statusGroup);
    m_officeStatusLabel->setStyleSheet("padding: 5px; border-radius: 3px; background-color: #f8f9fa;");

    statusLayout->addWidget(m_officeStatusLabel);
    layout->addWidget(statusGroup);

    // Details card
    QGroupBox *detailsGroup = new QGroupBox("Details", tabWidget);
    QGridLayout *detailsLayout = new QGridLayout(detailsGroup);

    m_officeEditionLabel = new QLabel("Edition: <b>Unknown</b>", detailsGroup);
    m_officeKmsLabel = new QLabel("KMS Server: Not Detected", detailsGroup);
    m_officeGracePeriodLabel = new QLabel("Grace Period: N/A", detailsGroup);
    m_officeLastDetectedLabel = new QLabel("Last Detected: Never", detailsGroup);

    detailsLayout->addWidget(m_officeEditionLabel, 0, 0);
    detailsLayout->addWidget(m_officeKmsLabel, 1, 0);
    detailsLayout->addWidget(m_officeGracePeriodLabel, 2, 0);
    detailsLayout->addWidget(m_officeLastDetectedLabel, 3, 0);

    layout->addWidget(detailsGroup);
    layout->addStretch();

    m_tabWidget->addTab(tabWidget, "Office License");
}

void MainWindow::createSettingsTab()
{
    QWidget *tabWidget = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(tabWidget);

    // System info group
    QGroupBox *sysGroup = new QGroupBox("System Information", tabWidget);
    QGridLayout *sysLayout = new QGridLayout(sysGroup);

    sysLayout->addWidget(new QLabel("Hostname:", sysGroup), 0, 0);
    m_hostnameLabel = new QLabel("Unknown", sysGroup);
    sysLayout->addWidget(m_hostnameLabel, 0, 1);

    sysLayout->addWidget(new QLabel("Machine GUID:", sysGroup), 1, 0);
    m_machineGuidLabel = new QLabel("Unknown", sysGroup);
    m_machineGuidLabel->setWordWrap(true);
    m_machineGuidLabel->setStyleSheet("word-wrap: break-word;");
    sysLayout->addWidget(m_machineGuidLabel, 1, 1);

    sysLayout->addWidget(new QLabel("Department:", sysGroup), 2, 0);
    m_departmentLabel = new QLabel("Unknown", sysGroup);
    sysLayout->addWidget(m_departmentLabel, 2, 1);

    layout->addWidget(sysGroup);

    // Service status group
    QGroupBox *serviceGroup = new QGroupBox("Service Status", tabWidget);
    QVBoxLayout *serviceLayout = new QVBoxLayout(serviceGroup);

    m_serviceStatusLabel = new QLabel("Service Status: <font color='red'><b>Offline</b></font>", serviceGroup);
    m_lastReportLabel = new QLabel("Last Report: Never", serviceGroup);

    serviceLayout->addWidget(m_serviceStatusLabel);
    serviceLayout->addWidget(m_lastReportLabel);

    layout->addWidget(serviceGroup);
    layout->addStretch();

    m_tabWidget->addTab(tabWidget, "Settings");
}

void MainWindow::createStatusBar()
{
    statusBar()->showMessage("Ready");
}

void MainWindow::createSystemTray()
{
    m_trayIcon = new SystemTrayIcon(this);
    connect(m_trayIcon, &SystemTrayIcon::doubleActivated, this, [this]() {
        showNormal();
        activateWindow();
    });

    m_trayIcon->show();
}

void MainWindow::changeEvent(QEvent *event)
{
    if (event->type() == QEvent::WindowStateChange) {
        if (windowState() & Qt::WindowMinimized) {
            hide();
            m_trayIcon->showMessage("License Checker", "Application minimized to system tray");
        }
    }
    QMainWindow::changeEvent(event);
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (m_trayIcon && m_trayIcon->isVisible()) {
        hide();
        event->ignore();
    } else {
        event->accept();
        qApp->quit();
    }
}

void MainWindow::onRefreshLicenseData()
{
    if (!m_pipeClient || !m_pipeClient->IsConnected()) {
        statusBar()->showMessage("Service not connected");
        return;
    }

    // Request license data from service via named pipe
    std::string response = m_pipeClient->SendCommand("GetLicenseData");

    if (response.empty()) {
        statusBar()->showMessage("Failed to get license data from service");
        return;
    }

    // Parse JSON response
    QJsonDocument doc = QJsonDocument::fromJson(QString::fromStdString(response).toUtf8());
    if (doc.isNull() || !doc.isObject()) {
        statusBar()->showMessage("Invalid response from service");
        return;
    }

    QJsonObject root = doc.object();
    if (root["status"].toString() != "success") {
        statusBar()->showMessage("Service error: " + root["error"].toString());
        return;
    }

    // Update data model with response
    QJsonObject data = root["data"].toObject();
    if (data.contains("windows")) {
        QJsonObject winObj = data["windows"].toObject();
        m_dataModel.windowsLicense().edition = winObj["edition"].toString();
        m_dataModel.windowsLicense().licenseStatus =
            static_cast<LicenseStatus>(winObj["licenseStatus"].toInt());
        m_dataModel.windowsLicense().kmsStatus =
            static_cast<KMSStatus>(winObj["kmsStatus"].toInt());
        m_dataModel.windowsLicense().kmsServer = winObj["kmsServer"].toString();
        m_dataModel.windowsLicense().lastDetected =
            QDateTime::fromString(winObj["lastDetected"].toString(), Qt::ISODate);
    }

    updateLicenseDisplay();
    m_refreshStatusLabel->setText("Last updated: " + formatDateTime(QDateTime::currentDateTime()));
    statusBar()->showMessage("License data refreshed");
}

void MainWindow::onForceCheckNow()
{
    m_forceCheckButton->setEnabled(false);
    m_refreshStatusLabel->setText("Checking...");
    statusBar()->showMessage("Requesting immediate license check...");

    if (!m_pipeClient || !m_pipeClient->IsConnected()) {
        statusBar()->showMessage("Service not connected");
        m_forceCheckButton->setEnabled(true);
        return;
    }

    // Send request to service for immediate check
    std::string response = m_pipeClient->SendCommand("RequestImmediateCheck");

    if (response.empty()) {
        statusBar()->showMessage("Failed to send check request");
        m_forceCheckButton->setEnabled(true);
        return;
    }

    // Wait a bit for service to complete detection, then refresh
    QTimer::singleShot(3000, this, [this]() {
        onRefreshLicenseData();
        m_forceCheckButton->setEnabled(true);
        statusBar()->showMessage("Check complete");
    });
}

void MainWindow::onCheckInCompleted()
{
    onRefreshLicenseData();
}

void MainWindow::onSystemTrayActivated(QSystemTrayIcon::ActivationReason reason)
{
    if (reason == QSystemTrayIcon::DoubleClick || reason == QSystemTrayIcon::Trigger) {
        if (isVisible()) {
            hide();
        } else {
            showNormal();
            activateWindow();
        }
    }
}

void MainWindow::updateLicenseDisplay()
{
    updateWindowsLicenseTab();
    updateOfficeLicenseTab();

    // Update system info tab
    m_hostnameLabel->setText(m_dataModel.systemInfo().hostname);
    m_machineGuidLabel->setText(m_dataModel.systemInfo().machineGuid);
    m_departmentLabel->setText(m_dataModel.systemInfo().department);

    QString serviceStatus = m_dataModel.systemInfo().serviceRunning
        ? "<font color='green'><b>Running</b></font>"
        : "<font color='red'><b>Offline</b></font>";
    m_serviceStatusLabel->setText("Service Status: " + serviceStatus);

    m_lastReportLabel->setText("Last Report: " + formatDateTime(m_dataModel.systemInfo().lastReportTime));

    // Update tray icon with current status
    if (m_trayIcon) {
        QString windowsStatus = m_dataModel.getLicenseStatusString(m_dataModel.windowsLicense().licenseStatus);
        QString officeStatus = m_dataModel.getLicenseStatusString(m_dataModel.officeLicense().licenseStatus);
        QString tooltip = QString("Windows: %1\nOffice: %2\nLast Check: %3")
            .arg(windowsStatus, officeStatus, formatDateTime(m_dataModel.lastRefreshTime()));
        m_trayIcon->setToolTip(tooltip);
    }
}

void MainWindow::updateWindowsLicenseTab()
{
    const LicenseInfo& license = m_dataModel.windowsLicense();

    QString statusText = QString("Status: <font color='%1'><b>%2</b></font>")
        .arg(m_dataModel.getLicenseStatusColor(license.licenseStatus).name(),
             m_dataModel.getLicenseStatusString(license.licenseStatus));
    m_windowsStatusLabel->setText(statusText);

    m_windowsEditionLabel->setText("Edition: <b>" + license.edition + "</b>");

    QString kmsText = "KMS Server: ";
    if (!license.kmsServer.isEmpty()) {
        kmsText += QString("<b>%1</b> (%2)")
            .arg(license.kmsServer, m_dataModel.getKMSStatusString(license.kmsStatus));
    } else {
        kmsText += "<b>Not Detected</b>";
    }
    m_windowsKmsLabel->setText(kmsText);

    m_windowsGracePeriodLabel->setText("Grace Period: " + (license.gracePeriod.isEmpty() ? "N/A" : license.gracePeriod));
    m_windowsLastDetectedLabel->setText("Last Detected: " + formatDateTime(license.lastDetected));
}

void MainWindow::updateOfficeLicenseTab()
{
    const LicenseInfo& license = m_dataModel.officeLicense();

    QString statusText = QString("Status: <font color='%1'><b>%2</b></font>")
        .arg(m_dataModel.getLicenseStatusColor(license.licenseStatus).name(),
             m_dataModel.getLicenseStatusString(license.licenseStatus));
    m_officeStatusLabel->setText(statusText);

    m_officeEditionLabel->setText("Edition: <b>" + license.edition + "</b>");

    QString kmsText = "KMS Server: ";
    if (!license.kmsServer.isEmpty()) {
        kmsText += QString("<b>%1</b> (%2)")
            .arg(license.kmsServer, m_dataModel.getKMSStatusString(license.kmsStatus));
    } else {
        kmsText += "<b>Not Detected</b>";
    }
    m_officeKmsLabel->setText(kmsText);

    m_officeGracePeriodLabel->setText("Grace Period: " + (license.gracePeriod.isEmpty() ? "N/A" : license.gracePeriod));
    m_officeLastDetectedLabel->setText("Last Detected: " + formatDateTime(license.lastDetected));
}

void MainWindow::displayLicenseInfo(const LicenseInfo& license, QGroupBox* group)
{
    // Helper for custom display logic if needed
    (void)license;
    (void)group;
}

QString MainWindow::formatDateTime(const QDateTime& dt) const
{
    if (!dt.isValid()) {
        return "Never";
    }
    return dt.toString("yyyy-MM-dd hh:mm:ss");
}

QString MainWindow::getStatusBadgeHtml(const LicenseInfo& license) const
{
    QColor color = m_dataModel.getLicenseStatusColor(license.licenseStatus);
    return QString("<span style='background-color: %1; color: white; padding: 4px 8px; border-radius: 3px;'>%2</span>")
        .arg(color.name(), m_dataModel.getLicenseStatusString(license.licenseStatus));
}
