#include "LicenseDetector.h"

LicenseDetector::LicenseDetector()
    : slApiDetector_(std::make_unique<SLAPIDetector>()),
      wmiDetector_(std::make_unique<WMIDetector>()),
      registryDetector_(std::make_unique<RegistryDetector>()) {
}

LicenseDetector::~LicenseDetector() {
}

// Main orchestration method: three-tier fallback strategy
LicenseResult LicenseDetector::Detect() {
    // Tier 1: Try SL API detection (fastest, most accurate on Windows 10/11)
    LicenseResult result = slApiDetector_->Detect();
    if (IsSuccessfulDetection(result)) {
        return result;  // Success on Tier 1
    }

    // Tier 2: SL API failed, try WMI detection (fallback for older Windows)
    result = wmiDetector_->Detect();
    if (IsSuccessfulDetection(result)) {
        return result;  // Success on Tier 2
    }

    // Tier 3: WMI failed, try registry detection (last resort)
    result = registryDetector_->Detect();
    if (IsSuccessfulDetection(result)) {
        return result;  // Success on Tier 3
    }

    // All tiers failed - return UnableToDetermine (FR-6)
    // Use the result from the last attempt but ensure it's marked as error
    if (result.GetLicenseStatus() == LicenseStatus::UnableToDetermine) {
        result.SetError(true);
        if (result.GetErrorMessage().empty()) {
            result.SetErrorMessage("All detection tiers failed: SL API, WMI, and Registry");
        }
    }

    return result;
}

// Helper: Determine if a detection result is successful
bool LicenseDetector::IsSuccessfulDetection(const LicenseResult& result) {
    // A detection is successful if:
    // 1. Status is not "UnableToDetermine"
    // 2. No error flag is set
    // 3. Windows version is valid (> 0)

    return result.GetLicenseStatus() != LicenseStatus::UnableToDetermine &&
           !result.IsError() &&
           result.GetWindowsVersion() > 0;
}
