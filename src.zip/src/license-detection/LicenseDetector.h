#pragma once

#include "LicenseResult.h"
#include "SLAPIDetector.h"
#include "WMIDetector.h"
#include "RegistryDetector.h"
#include <memory>

// Main license detection orchestrator
// Implements three-tier fallback strategy: SL API → WMI → Registry (FR-1)
class LicenseDetector {
public:
    LicenseDetector();
    ~LicenseDetector();

    // Delete copy semantics
    LicenseDetector(const LicenseDetector&) = delete;
    LicenseDetector& operator=(const LicenseDetector&) = delete;

    // Allow move semantics
    LicenseDetector(LicenseDetector&&) noexcept = default;
    LicenseDetector& operator=(LicenseDetector&&) noexcept = default;

    // Main detection method: orchestrates three-tier fallback
    // Returns result from first successful tier, or UnableToDetermine if all fail (FR-6)
    LicenseResult Detect();

private:
    // Detector instances for each tier
    std::unique_ptr<SLAPIDetector> slApiDetector_;
    std::unique_ptr<WMIDetector> wmiDetector_;
    std::unique_ptr<RegistryDetector> registryDetector_;

    // Helper: Check if detection result is successful
    static bool IsSuccessfulDetection(const LicenseResult& result);
};
