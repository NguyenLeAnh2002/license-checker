TEMPLATE = app
CONFIG += c++17 console

TARGET = LicenseCheckerAgent

SOURCES += \
    ServiceMain.cpp \
    LicenseDetectionWorker.cpp \
    ServiceInstaller.cpp \
    NotificationFormatter.cpp

HEADERS += \
    LicenseDetectionWorker.h \
    NotificationFormatter.h

win32 {
    LIBS += -ladvapi32 -lkernel32 -lwsock32 -lwtsapi32
}

# Link to our libraries
win32-g++ {
    LIBS += \
        -L$$OUT_PWD/../license-detection -llicense_detection \
        -L$$OUT_PWD/../common -lcommon
}

INCLUDEPATH += $$PWD \
               $$PWD/../license-detection \
               $$PWD/../common

DEPENDPATH += $$PWD/../license-detection \
              $$PWD/../common
