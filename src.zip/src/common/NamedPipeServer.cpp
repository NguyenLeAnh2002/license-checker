#include "NamedPipeServer.h"
#include "../license-detection/LicenseResult.h"
#include "../license-detection/LicenseStatusEnum.h"
#include <sstream>
#include <iostream>
#include <ctime>
#include <iomanip>

NamedPipeServer::NamedPipeServer(const std::string& pipeName)
    : m_pipeName(pipeName),
      m_pipeHandle(INVALID_HANDLE_VALUE),
      m_isRunning(false),
      m_stopRequested(false)
{
}

NamedPipeServer::~NamedPipeServer()
{
    Stop();
}

void NamedPipeServer::Start()
{
    if (m_isRunning) {
        return;
    }

    m_stopRequested = false;
    m_isRunning = true;
    m_listenThread = std::thread(&NamedPipeServer::ListenThread, this);
}

void NamedPipeServer::Stop()
{
    if (!m_isRunning) {
        return;
    }

    m_stopRequested = true;

    if (m_pipeHandle != INVALID_HANDLE_VALUE) {
        DisconnectNamedPipe(m_pipeHandle);
        CloseHandle(m_pipeHandle);
        m_pipeHandle = INVALID_HANDLE_VALUE;
    }

    if (m_listenThread.joinable()) {
        m_listenThread.join();
    }

    m_isRunning = false;
}

bool NamedPipeServer::IsRunning() const
{
    return m_isRunning;
}

void NamedPipeServer::SetRequestHandler(RequestHandler handler)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    m_requestHandler = handler;
}

void NamedPipeServer::SendNotification(const std::string& message)
{
    // In a real implementation, this would broadcast to all connected clients
    // For now, it's a placeholder for sending unsolicited notifications
}

void NamedPipeServer::ListenThread()
{
    std::string fullPipeName = "\\\\.\\pipe\\" + m_pipeName;

    while (!m_stopRequested) {
        // Create named pipe
        HANDLE hPipe = CreateNamedPipeA(
            fullPipeName.c_str(),
            PIPE_ACCESS_DUPLEX,
            PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
            1,  // Single instance (UI client)
            4096,  // Output buffer size
            4096,  // Input buffer size
            0,  // Default timeout
            nullptr  // Default security attributes
        );

        if (hPipe == INVALID_HANDLE_VALUE) {
            std::cerr << "Failed to create named pipe" << std::endl;
            break;
        }

        m_pipeHandle = hPipe;

        // Wait for client connection
        if (ConnectNamedPipe(hPipe, nullptr) || GetLastError() == ERROR_PIPE_CONNECTED) {
            HandleClient(hPipe);
        }

        DisconnectNamedPipe(hPipe);
        CloseHandle(hPipe);
        m_pipeHandle = INVALID_HANDLE_VALUE;
    }
}

void NamedPipeServer::HandleClient(HANDLE hPipe)
{
    while (!m_stopRequested) {
        std::string request = ReadFromPipe(hPipe);

        if (request.empty()) {
            break;  // Client disconnected
        }

        // Parse command (simple format: "command:payload")
        size_t colonPos = request.find(':');
        std::string command = (colonPos != std::string::npos) ? request.substr(0, colonPos) : request;
        std::string payload = (colonPos != std::string::npos) ? request.substr(colonPos + 1) : "";

        std::string response;

        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_requestHandler) {
                response = m_requestHandler(command, payload);
            } else {
                response = BuildErrorResponse("No handler registered");
            }
        }

        if (!WriteToClient(hPipe, response)) {
            break;  // Failed to write, client disconnected
        }
    }
}

std::string NamedPipeServer::ReadFromPipe(HANDLE hPipe)
{
    char buffer[4096] = {0};
    DWORD bytesRead = 0;

    if (ReadFile(hPipe, buffer, sizeof(buffer) - 1, &bytesRead, nullptr)) {
        return std::string(buffer, bytesRead);
    }

    return "";  // Error or client disconnected
}

bool NamedPipeServer::WriteToClient(HANDLE hPipe, const std::string& data)
{
    DWORD bytesWritten = 0;

    if (WriteFile(hPipe, data.c_str(), static_cast<DWORD>(data.length()), &bytesWritten, nullptr)) {
        return true;
    }

    return false;
}

std::string NamedPipeServer::BuildLicenseDataResponse(const LicenseResult& result)
{
    std::ostringstream json;

    // Convert timestamp to ISO8601
    std::time_t timestamp = std::chrono::system_clock::to_time_t(result.GetTimestamp());
    struct tm timeinfo;
    localtime_s(&timeinfo, &timestamp);
    char timestampBuffer[30];
    strftime(timestampBuffer, sizeof(timestampBuffer), "%Y-%m-%dT%H:%M:%SZ", &timeinfo);

    json << "{";
    json << "\"status\":\"success\",";
    json << "\"data\":{";
    json << "\"windows\":{";
    json << "\"edition\":\"" << result.GetWindowsEdition() << "\",";
    json << "\"licenseStatus\":" << static_cast<int>(result.GetLicenseStatus()) << ",";
    json << "\"kmsStatus\":" << static_cast<int>(result.GetKmsStatus()) << ",";
    json << "\"kmsServer\":\"" << result.GetWindowsKmsServer() << "\",";
    json << "\"lastDetected\":\"" << timestampBuffer << "\"";
    json << "}";
    json << "}";
    json << "}";

    return json.str();
}

std::string NamedPipeServer::BuildErrorResponse(const std::string& error)
{
    std::ostringstream json;
    json << "{\"status\":\"error\",\"error\":\"" << error << "\"}";
    return json.str();
}

std::string NamedPipeServer::BuildSuccessResponse(const std::string& message)
{
    std::ostringstream json;
    json << "{\"status\":\"success\",\"message\":\"" << message << "\"}";
    return json.str();
}
