TEMPLATE = lib
CONFIG += staticlib c++17

TARGET = common

SOURCES += \
    NamedPipeServer.cpp \
    NamedPipeClient.cpp \
    SharedLicenseDataWriter.cpp

HEADERS += \
    NamedPipeServer.h \
    NamedPipeClient.h \
    SharedLicenseDataWriter.h

win32 {
    LIBS += -ladvapi32 -lkernel32 -lws2_32
}

# Link to license detection library
win32-g++ {
    LIBS += -L$$OUT_PWD/../license-detection -llicense_detection
}

INCLUDEPATH += $$PWD \
               $$PWD/../license-detection

DEPENDPATH += $$PWD/../license-detection
